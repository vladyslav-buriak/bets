// Task 1.

// let a = 4;
// if (a = 4) {
//     console.log(true);
// } 

// Task 1. ООП

// class Variable {
//     constructor(a) {
//         this.a = a;
//     }

//     showVariableInfo() {
//         if (this.a == 4) {
//             console.log(true);
//         }
//     }
// }

// let v = new Variable(this.a = 4)
// v.showVariableInfo();

// Task 2.

// let b = 8;
// let c = 10;
// if (b > c) {
//     console.log('b > ')
// } else {
//     console.log('c > ');
// }

// Task 2. ООП

// class Variable {
//     constructor(b, c) {
//         this.b = b;
//         this.c = c
//     }

//     showVariableInfo() {
//         this.b = 8;
//         this.c = 10;
//     }

//     comparisonVariableInfo() {
//         if (this.b > this.c) {
//             console.log('b > is bigger')
//         } else {
//             console.log('c is bigger')
//         }
//     }
// }

// let v = new Variable();
// v.comparisonVariableInfo();

// Task 4.

// let btn = document.querySelector('button').onclick = function () {
//     let input1 = document.querySelector('#i1').value;
//     let input2 = document.querySelector('#i2').value;

//     if (+input1 > +input2) {
//         console.log(+input1)
//     }
//     else if (+input1 == +input2) {
//         console.log('value is =')
//     } else {
//         console.log(+input2)
//     }
// }


// Task 5.

// document.querySelector('button').onclick = () => {

//     let input = document.querySelector('input').value;
//     let p = document.querySelector('p');
//     let yearNow = 2019;
//     let yearEnter = 2000;

//     if (input < yearEnter) {
//         p.textContent = yearNow - input;
//     } else {
//         (input >= yearEnter)
//         console.log(yearNow - input);
//     }
// }

// Task 7.

// document.querySelector('button').onclick = () => {

//     let inputValue = document.querySelector('input').value;
//     let num = 0;

//     if (inputValue > num) {
//         alert(inputValue + ' ' + 'Больше' + ' ' + num);
//     }
//     else if (inputValue == num) {
//         alert(inputValue + ' ' + 'Равен' + ' ' + num);
//     }
//     else {
//         alert(inputValue + ' ' + 'Меньше' + ' ' + num);
//     }
// }

// Task 8.

// let btn = document.querySelector('button');
// btn.onclick = evenOrOdd;

// function evenOrOdd() {

//     let inputValue = document.querySelector('input').value;
//     if (inputValue % 2 == 0) {
//         alert('Четное')
//     } else {
//         alert('Нечетное')
//     }
// }

// Task 10.

// document.querySelector('button').onclick = hello;

// function hello() {
//     let inputValue = document.querySelector('input').value;
//     if (inputValue.length == 0) {
//         alert('заполните поле');
//     } else {
//         alert('Hello' + ' ' + inputValue)
//     }
// }


// Task 11.

// document.querySelector('button').onclick = hello;

// function hello() {

//     let input = document.querySelector('input');
//     let inputValue = input.value.trim();

//     if (inputValue == '') {
//         alert('заполните поля');
//         return false;
//     } else {
//         alert('Hello' + ' ' + inputValue);
//     }
// }


// Task 13.

// document.querySelector('button').onclick = () => {

//     let input = document.querySelector('input').value;
//     let numberHouse = input;

//     if (numberHouse > 0 && numberHouse < 6) {
//         alert('street 1');
//     }
//     else if (numberHouse > 5 && numberHouse < 12) {
//         alert('street 2');
//     }
//     else if (numberHouse > 11 && numberHouse < 21) {
//         alert('street 3');
//     }
// }


// Task 14.

// document.querySelector('input').oninput = () => {

//     let input = document.querySelector('input');
//     let rengent = input.value;
//     let p = document.querySelector('p');

//     if (rengent >= 0 && rengent <= 25) {
//         p.textContent = rengent + ' ' + '- не обноружено!';
//     }
//     else if (rengent >= 26 && rengent <= 50) {
//         p.textContent = rengent + ' ' + '- снижение числа лимфоцитов';
//     }
//     else if (rengent >= 51 && rengent <= 100) {
//         p.textContent = rengent + ' ' + '- вялость, рвота';
//     }
//     else if (rengent >= 101 && rengent <= 150) {
//         p.textContent = rengent + ' ' + '- смертность 5%';
//     }
//     else if (rengent >= 151 && rengent <= 350) {
//         p.textContent = rengent + ' ' + '- смертность 50% за 30 суток';
//     }
//     else if (rengent >= 351 && rengent <= 600) {
//         p.textContent = rengent + ' ' + '-  90% смертность за 2 недели';
//     }
// }

// Task 16.

// document.querySelector('button').onclick = () => {
//     let input = document.querySelector('input').value;
//     let tax = input;

//     if (tax >= 1 && tax <= 500) {
//         alert('налог 2025 тенге');
//     }
//     else if (tax >= 501 && tax <= 1200) {
//         alert('налог 5050 тенге');
//     }
//     else if (tax >= 1201 && tax <= 1600) {
//         alert('налог 8275 тенге');
//     }
//     else if (tax >= 1601 && tax <= 1900) {
//         alert('налог 8675 тенге');
//     }
//     else if (tax >= 1901 && tax <= 2000) {
//         alert('налог 11075 тенге');
//     }
//     else {
//         alert('введите данные из таблици кофициентов');
//         return false;
//     }

// }
