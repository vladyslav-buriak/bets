
document.querySelector('input').onkeypress = function (e) {
    console.log(e);
}