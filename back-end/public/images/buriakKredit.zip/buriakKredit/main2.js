
// функция карусель
let move = 0;

// запускаем один блок по маусеЕнтер + з-индекс
document.querySelector('.section').onmouseenter = () => {
    let offSection = document.querySelector('.info section');
    let onSection = document.querySelector('.section');
    onSection.classList.add('z-index');
    onSection.style.left = move - 300 + 'px';
    offSection.style.left = move + 400 + 'px';
}

// запускаем второй блок по маусеЕнтер - з-индекс
document.querySelector('.info section').onmouseenter = () => {
    let onSection = document.querySelector('.info section');
    let offSection = document.querySelector('.section');
    onSection.style.left = move + 120 + 'px';
    offSection.classList.remove('z-index');
    offSection.style.left = move - 20 + 'px';
}



// модальное окно входа

//открытие по кнопки

let btnOn = document.querySelectorAll('.menu__link');
for (let i = 0; i < btnOn.length; i++) {
    btnOn[i].onclick = showWindow;
}

//закрытие по крестику

let close = document.querySelectorAll('.window__close');
for (let i = 0; i < close.length; i++) {
    close[i].onclick = closeWindow;
}

//закрытие по обертке

let modalWrap = document.querySelectorAll('.modal-wrap');
for (let i = 0; i < modalWrap.length; i++) {
    modalWrap[i].onclick = closeWindow;
}

// показ модального окна

function showWindow() {
    let windowId = this.dataset.window;
    console.log(windowId);
    document.querySelector(windowId).classList.remove('hide');
    document.onkeydown = function (event) {
        if (event.keyCode == 27) {
            closeWindow();
        }
    }
}

// закрытие модального окна

function closeWindow() {
    let modalWrap = document.querySelectorAll('.modal-wrap');
    for (let i = 0; i < modalWrap.length; i++) {
        modalWrap[i].classList.add('hide');
        document.onkeydown = null;
    }
}

// функция стоп пропагейшн

let modalInputs = document.querySelectorAll('.modal__inputs');
let modal = document.querySelector('.modal-window');

// берем все елементы которые нужны для стоп пропагейшена в массив

let data = [modal, modalInputs];
for (let i = 0; i < data.length; i++) {
    data[i].onclick = canClick;
}

function canClick(event) {
    event.stopPropagation();
}



