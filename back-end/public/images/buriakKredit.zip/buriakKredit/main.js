// функция подсчета суммы

document.querySelector('.money__range').oninput = rangeMoney; // ползунок сумма
document.querySelector('.day__range').oninput = rangeDays; // ползунок дни
document.querySelector('.money__input').oninput = inputMoney;// инпут ввод суммы
document.querySelector('.day__input').oninput = inputDay;// инпут ввод дней

// функция ввод в инпут дата
// если длинна числа больше 2 или значение больше 30
// то мы обрезаем слайсом до 0 и выводит алерт

function inputDay() {
    if (this.length > 2 || this.value > 30) {
        this.value = this.value.slice(0, 0);
        alert('максимальная дата 30 дней');
    }
    document.querySelector('.day__range').value = this.value;
    result();
}

// функция ввод в инпут сумы
// если длинна числа больше 5 или значения больше 10 тысяч
// то мы обрезаем слайсом до 0 и выводит алерт

function inputMoney() {
    if (this.length > 5 || this.value > 10000) {
        this.value = this.value.slice(0, 0);
        alert('максимальная сумма 10 000');

    }
    document.querySelector('.money__range').value = this.value;
    result();
}

// функция результат
// берем ползунок денег и ползунок дней и окгругляем
// в переменной дейли просент умножаем (сумму* дни * проценты)
// в переменной результат плюсуем и переводим в числовой тип дейли просент и плюсуем ползунок суммы
// берем 3 параграфа перебераем их циклом и выводим через текст контент
// п-1 суму всю п-2 проценты п-3 кол-дней

function result() {

    let procent = 0.014;
    let = rangeMoney = parseInt(Math.round(document.querySelector('.money__range').value));
    let = rangeDays = parseInt(Math.round(document.querySelector('.day__range').value));

    let dayliProcent = Math.round(rangeMoney * procent * rangeDays);
    let res = parseInt(dayliProcent) + parseInt(rangeMoney);
    let all = document.querySelectorAll('.calc__text');

    for (let i = 0; i < all.length; i++) {
        all[0].textContent = res + ' ' + 'Повертаете' + ' ' + 'грн';
        all[1].textContent = dayliProcent + ' ' + ' %' + ' ' + 'грн';
        all[2].textContent = rangeDays + 'д';
    }
}

result();

// управляем ползунком суммы и выводим значение + вставили функцию резалт
// и получем сумму и полузнокм смотрим проценты от суммы займа

function rangeMoney() {

    document.querySelector('.money__input').value = this.value;
    result();
}

// управляем ползунком дней и выводим значение + вставили функцию резалт
// и получем дни и проценты от этих дней

function rangeDays() {

    document.querySelector('.day__input').value = this.value;
    result();
}


// функция слайдер отзывы клиентов

// слайдер по событию онклик влево

document.querySelector('.left').onclick = leftClick;

// слайдер по событию онклик право
document.querySelector('.right').onclick = rightClick;

// берем все отзывы и фото
let rewiev = document.querySelectorAll('.slider');
let current = 0;

// перебираем циклом все отзывы и фото
// всемфото и  отзываем добовляем опасити
// текущему отзыву с фото удаляем опасити

function slider() {

    for (let i = 0; i < rewiev.length; i++) {

        rewiev[i].classList.add('opacity0')
    }
    rewiev[current].classList.remove('opacity0');
}

slider();

// и берем клик в право в сет интервал для бесконечного слайдера вправо

function timerRight(timerClick = 10000) {

    setInterval(rightClick, timerClick)
}

timerRight();

// клик влево

function leftClick() {

    if (current - 1 == -1) {
        current = rewiev.length - 1;
    } else {
        current--;
    }
    slider();
}

// клик вправо

function rightClick() {
    if (current + 1 == rewiev.length) {
        current = 0;
    } else {
        current++;
    }
    slider();
}

// модальное окно входа

//открытие по кнопки

let btnOn = document.querySelectorAll('.menu__link');

for (let i = 0; i < btnOn.length; i++) {
    btnOn[i].onclick = showWindow;
}

//закрытие по крестику

let close = document.querySelectorAll('.window__close');

for (let i = 0; i < close.length; i++) {
    close[i].onclick = closeWindow;
}

//закрытие по обертке

let modalWrap = document.querySelectorAll('.modal-wrap');

for (let i = 0; i < modalWrap.length; i++) {
    modalWrap[i].onclick = closeWindow;
}

// показ модального окна

function showWindow() {

    let windowId = this.dataset.window;
    console.log(windowId);
    document.querySelector(windowId).classList.remove('hide');
    document.onkeydown = function (event) {
        if (event.keyCode == 27) {
            closeWindow();
        }
    }
}

// закрытие модального окна

function closeWindow() {

    let modalWrap = document.querySelectorAll('.modal-wrap');
    for (let i = 0; i < modalWrap.length; i++) {
        modalWrap[i].classList.add('hide');
        document.onkeydown = null;
    }
}

// функция стоп пропагейшн

let modalInputs = document.querySelectorAll('.modal__inputs');
let modal = document.querySelector('.modal-window');

// берем все елементы которые нужны для стоп пропагейшена в массив

let data = [modal, modalInputs];

for (let i = 0; i < data.length; i++) {
    data[i].onclick = canClick;
}

function canClick(event) {
    event.stopPropagation();
}

// функция ввод только цифры и буквы , в поля емейл пароль
// берем поля в цикл

for (let i = 0; i < modalInputs.length; i++) {
    modalInputs[i].onkeypress = inputsCharts;
}

function inputsCharts(e) {

    if (e.keyCode < 64 || e.keyCode > 90 && e.keyCode < 97 || e.keyCode > 122) {
        if (e.keyCode < 46 || e.keyCode > 57) {
            return false;
        }
        if (e.keyCode == 47) {
            return false;
        }
    }
    else return true;
}



